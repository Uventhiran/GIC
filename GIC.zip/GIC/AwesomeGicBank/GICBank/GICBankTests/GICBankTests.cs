using System.Security.Principal;
using GICBank;
using GICBank.Models;

namespace GICBankTests
{
    public class GICBankTests
    {

        [Fact]
        public void TestAddInterestRule()
        {
     
            Bank bank = new Bank();

            // Act
            bank.AddInterestRule(new InterestRule("20230601", "RULE01", 1.9M));
            bank.AddInterestRule(new InterestRule("20230501", "RULE02", 2.2M));  // Adding another rule

            // Assert
            Assert.Equal(2, bank.interestRules.Count);  // Ensure two rules exist
            Assert.Equal("RULE02", bank.interestRules[0].RuleId); // Check if sorted by date
            Assert.Equal("RULE01", bank.interestRules[1].RuleId);
        }

        [Fact]
        public void TestAccountCreation()
        {
          
            Bank bank = new Bank();

            // Act
            Account account = bank.GetOrCreateAccount("AC001");

            // Assert
            Assert.NotNull(account);
            Assert.Equal("AC001", account.AccountId);
            Assert.Equal(0, account.Balance);
        }

        [Fact]
        public void TestDepositTransaction()
        {
          
            Bank bank = new Bank();
            Account account = bank.GetOrCreateAccount("AC001");

            // Act
            account.AddTransaction(new Transaction("20230601", "20230601-01", "D", 150));

            // Assert
            Assert.Equal(150, account.Balance);
            Assert.Single(account.Transactions); // Since only 1 transaction was added
            Assert.Equal("D", account.Transactions[0].Type);
        }


        [Fact]
        public void TestWithdrawalTransaction()
        {
          
            Bank bank = new Bank();
            Account account = bank.GetOrCreateAccount("AC001");
            account.AddTransaction(new Transaction("20230601", "20230601-01", "D", 150)); // Deposit first

            // Act
            account.AddTransaction(new Transaction("20230626", "20230626-01", "W", 50));

            // Assert
            Assert.Equal(100, account.Balance); // Balance after withdrawal
            Assert.Equal(2, account.Transactions.Count); // Two transactions in the account
            Assert.Equal("W", account.Transactions[1].Type);
        }

        [Fact]
        public void TestWithdrawalExceedsBalance()
        {
          
            Bank bank = new Bank();
            Account account = bank.GetOrCreateAccount("AC001");
            account.AddTransaction(new Transaction("20230601", "20230601-01", "D", 100)); // Deposit 100

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() =>
            {
                account.AddTransaction(new Transaction("20230626", "20230626-01", "W", 150)); // Withdraw 150 (invalid)
            });
        }

        [Fact]
        public void TestInvalidAmountForWithdrawal()
        {
            
            Bank bank = new Bank();
            Account account = bank.GetOrCreateAccount("AC001");
            account.AddTransaction(new Transaction("20230601", "20230601-01", "D", 100)); // Deposit 100

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() =>
            {
                account.AddTransaction(new Transaction("20230626", "20230626-01", "W", 200)); // Withdrawal exceeding balance
            });
        }

    }
}