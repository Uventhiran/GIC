﻿using GICBank.Models;
using GICBank;

class Program
{
    static void Main()
    {
        Bank bank = new Bank();

        while (true)
        {
            Console.WriteLine("Welcome to AwesomeGIC Bank! What would you like to do?");
            Console.WriteLine("[T] Input transactions");
            Console.WriteLine("[I] Define interest rules");
            Console.WriteLine("[P] Print statement");
            Console.WriteLine("[Q] Quit");
            Console.Write("> ");
            string action = Console.ReadLine()?.ToUpper();

            if (action == "Q")
            {
                Console.WriteLine("Thank you for banking with AwesomeGIC Bank. Have a nice day!");
                break;
            }

            switch (action)
            {
                case "T":
                    HandleTransactions(bank);
                    break;
                case "I":
                    HandleInterestRules(bank);
                    break;
                case "P":
                    HandlePrintStatement(bank);
                    break;
                default:
                    Console.WriteLine("Invalid option, please try again.");
                    break;
            }
        }
    }

    static void HandleTransactions(Bank bank)
    {
        while (true)
        {
            Console.WriteLine("Please enter transaction details in <Date> <Account> <Type> <Amount> format (or enter blank to go back to main menu):");
            Console.Write("> ");
            string input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) break;

            string[] parts = input.Split(" ");
            if (parts.Length != 4) continue;

            string date = parts[0];
            string accountId = parts[1];
            string type = parts[2].ToUpper();
            decimal amount;

            if (!decimal.TryParse(parts[3], out amount) || amount <= 0 || (type == "W" && bank.GetOrCreateAccount(accountId).Balance < amount))
            {
                Console.WriteLine("Invalid transaction, please check your input.");
                continue;
            }

            Account account = bank.GetOrCreateAccount(accountId);
            string txnId = $"{date}-{account.Transactions.Count + 1:D2}";
            account.AddTransaction(new Transaction(date, txnId, type, amount));

            bank.PrintStatement(accountId, date.Substring(0, 6));
        }
    }

    static void HandleInterestRules(Bank bank)
    {
        while (true)
        {
            Console.WriteLine("Please enter interest rules details in <Date> <RuleId> <Rate in %> format (or enter blank to go back to main menu):");
            Console.Write("> ");
            string input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) break;

            string[] parts = input.Split(" ");
            if (parts.Length != 3) continue;

            string date = parts[0];
            string ruleId = parts[1];
            decimal rate;

            if (!decimal.TryParse(parts[2], out rate) || rate <= 0 || rate >= 100)
            {
                Console.WriteLine("Invalid interest rule, please check your input.");
                continue;
            }

            bank.AddInterestRule(new InterestRule(date, ruleId, rate));
            Console.WriteLine("Interest rules:");
            Console.WriteLine("| Date     | RuleId | Rate (%) |");
            foreach (var rule in bank.interestRules)
            {
                Console.WriteLine($"| {rule.Date} | {rule.RuleId} | {rule.Rate} |");
            }
        }
    }

    static void HandlePrintStatement(Bank bank)
    {
        Console.WriteLine("Please enter account and month to generate the statement <Account> <Year><Month>");
        Console.Write("> ");
        string input = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(input)) return;

        string[] parts = input.Split(" ");
        if (parts.Length != 2) return;

        string accountId = parts[0];
        string yearMonth = parts[1];
        bank.PrintStatement(accountId, yearMonth);
    }
}
