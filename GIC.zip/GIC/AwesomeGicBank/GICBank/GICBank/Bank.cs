﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GICBank.Models;

namespace GICBank
{
    public class Bank
{
    public Dictionary<string, Account> accounts;
    public List<InterestRule> interestRules;

    public Bank()
    {
        accounts = new Dictionary<string, Account>();
        interestRules = new List<InterestRule>();
    }

    public Account GetOrCreateAccount(string accountId)
    {
        if (!accounts.ContainsKey(accountId))
        {
            accounts[accountId] = new Account(accountId);
        }
        return accounts[accountId];
    }

    public void AddInterestRule(InterestRule rule)
    {
        // If the rule already exists for the date, we update it
        var existingRule = interestRules.FirstOrDefault(r => r.Date == rule.Date);
        if (existingRule != null)
        {
            interestRules.Remove(existingRule);
        }
        interestRules.Add(rule);
        interestRules = interestRules.OrderBy(r => r.Date).ToList();
    }

    public void PrintStatement(string accountId, string yearMonth)
    {
        if (!accounts.ContainsKey(accountId)) return;

        var account = accounts[accountId];
        Console.WriteLine($"Account: {accountId}");
        Console.WriteLine("| Date     | Txn Id      | Type | Amount | Balance |");

        decimal balance = 0;
        foreach (var txn in account.Transactions.Where(t => t.Date.StartsWith(yearMonth)))
        {
            balance += txn.Type == "D" ? txn.Amount : -txn.Amount;
            Console.WriteLine($"| {txn.Date} | {txn.TxnId} | {txn.Type} | {txn.Amount:F2} | {balance:F2} |");
        }

        // Calculate interest
        decimal interest = CalculateInterest(accountId, yearMonth);
        if (interest > 0)
        {
            Console.WriteLine($"| {yearMonth + "30"} |             | I    | {interest:F2} | {balance + interest:F2} |");
        }
    }

    public decimal CalculateInterest(string accountId, string yearMonth)
    {
        // Calculate interest based on transactions and rules for the given month
        var account = accounts[accountId];
        decimal totalInterest = 0;

        var dateRange = GetDateRange(yearMonth);
        foreach (var rule in interestRules.Where(r => DateTime.Parse(r.Date) <= dateRange.Item2))
        {
            decimal balanceForPeriod = account.Transactions.Where(t => DateTime.Parse(t.Date) >= dateRange.Item1 && DateTime.Parse(t.Date) <= dateRange.Item2)
                                                          .Sum(t => t.Type == "D" ? t.Amount : -t.Amount);

            decimal interest = balanceForPeriod * rule.Rate / 100 * (dateRange.Item2 - dateRange.Item1).Days / 365;
            totalInterest += interest;
        }

        return totalInterest;
    }

    private Tuple<DateTime, DateTime> GetDateRange(string yearMonth)
    {
        DateTime startDate = DateTime.ParseExact(yearMonth + "01", "yyyyMMdd", null);
        DateTime endDate = startDate.AddMonths(1).AddDays(-1);
        return Tuple.Create(startDate, endDate);
    }
}

}
