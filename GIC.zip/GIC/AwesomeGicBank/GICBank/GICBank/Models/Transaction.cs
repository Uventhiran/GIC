﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GICBank.Models
{
    public class Transaction
{
    public string Date { get; }
    public string TxnId { get; }
    public string Type { get; }
    public decimal Amount { get; }

    public Transaction(string date, string txnId, string type, decimal amount)
    {
        Date = date;
        TxnId = txnId;
        Type = type;
        Amount = amount;
    }
}

}
