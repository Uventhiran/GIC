﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GICBank.Models
{
    public class Account
    {
        public string AccountId { get; }
        public List<Transaction> Transactions { get; set; }
        public decimal Balance { get; set; }

        public Account(string accountId)
        {
            AccountId = accountId;
            Transactions = new List<Transaction>();
            Balance = 0;
        }

        public void AddTransaction(Transaction transaction)
        {
            // Check if transaction is a withdrawal and ensure sufficient balance
            if (transaction.Type == "W" && Balance < transaction.Amount)
            {
                throw new InvalidOperationException("Insufficient funds for withdrawal.");
            }

            // Add the transaction and adjust the balance
            Transactions.Add(transaction);

            if (transaction.Type == "D")
            {
                Balance += transaction.Amount;  // Deposit increases balance
            }
            else if (transaction.Type == "W")
            {
                Balance -= transaction.Amount;  // Withdrawal decreases balance
            }
        }
    }

}
